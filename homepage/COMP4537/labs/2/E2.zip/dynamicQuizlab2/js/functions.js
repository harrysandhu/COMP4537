class Question()
function genid(){
    let r = Math.random().toString(36).substring(7);
    return r
}
